#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <assert.h>
#include "node.h"
#include "debug.h"
#include "gen.h"
#include "symtab.h"
void parse_node(node *n);
